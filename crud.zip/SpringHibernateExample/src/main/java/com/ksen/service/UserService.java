package com.ksen.service;

import java.util.List;

import com.ksen.model.User;

public interface UserService {

	User findById(int id);
	
	void saveEmployee(User user);
	
	void updateEmployee(User user);
	
	void deleteEmployeeById(int id);

	List<User> findAllEmployees(); 
	
	
}
