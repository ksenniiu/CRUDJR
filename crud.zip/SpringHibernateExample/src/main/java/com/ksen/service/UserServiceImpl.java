package com.ksen.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ksen.model.User;
import com.ksen.dao.UserDao;

@Service("employeeService")
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao dao;
	
	public User findById(int id) {
		return dao.findById(id);
	}

	public void saveEmployee(User user) {
		dao.saveEmployee(user);
	}

	public void updateEmployee(User user) {
		User entity = dao.findById(user.getId());
		if(entity!=null){
			entity.setName(user.getName());
			entity.setCreatedDate(user.getCreatedDate());
			entity.setAge(user.getAge());
                        entity.setIsAdmin(user.getIsAdmin());
		}
	}

	public void deleteEmployeeById(int id) {
		dao.deleteEmployeeById(id);
	}
	
	public List<User> findAllEmployees() {
		return dao.findAllEmployees();
	}

	
}
