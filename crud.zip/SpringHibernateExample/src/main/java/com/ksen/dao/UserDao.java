package com.ksen.dao;

import java.util.List;

import com.ksen.model.User;

public interface UserDao {

	User findById(int id);

	void saveEmployee(User user);
	
	void deleteEmployeeById(int id);
	
	List<User> findAllEmployees();

}
