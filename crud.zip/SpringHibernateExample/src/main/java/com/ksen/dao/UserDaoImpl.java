package com.ksen.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ksen.model.User;

@Repository("employeeDao")
public class UserDaoImpl extends AbstractDao<Integer, User> implements UserDao {

	public User findById(int id) {
		return getByKey(id);
	}

	public void saveEmployee(User user) {
		persist(user);
	}

	public void deleteEmployeeById(int id) {
		Query query = getSession().createSQLQuery("delete from User where id = :id");
		query.setInteger("id", id);
		query.executeUpdate();
	}

	@SuppressWarnings("unchecked")
	public List<User> findAllEmployees() {
		Criteria criteria = createEntityCriteria();
		return (List<User>) criteria.list();
	}

}
