(function($){
    
    $(document).ready(function(){
    
        $(".pagination").customPaginate({
        
            itemsToPaginate : ".post",
			
			activeClass : "active-class"
        
        });
    
    });
    
})(jQuery)